from setuptools import setup, find_packages

setup(
    name="custom-cli-lang",
    version="0.1.0",
    description="A Custom CLI Language Interpreter for Windows tasks.",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    author="Your Name",
    author_email="your.email@example.com",
    url="https://github.com/yourusername/custom-cli-lang",
    packages=find_packages(),
    include_package_data=True,
    install_requires=[],
    entry_points={
        "console_scripts": [
            "cli-lang=cli_lang.cli_interpreter:main",
        ],
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: Microsoft :: Windows",
    ],
    python_requires=">=3.7",
)
